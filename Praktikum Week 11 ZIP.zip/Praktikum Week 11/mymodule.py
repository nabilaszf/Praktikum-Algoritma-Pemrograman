def greeting(Bila):
    print("Hello, " + Bila)