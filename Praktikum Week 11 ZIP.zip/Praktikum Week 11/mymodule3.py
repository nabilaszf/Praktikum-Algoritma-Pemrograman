def greeting(Bila):
    print("Hello, " + Bila)
orang1 = {
    "Nama": "Nabila Firlina",
    "Umur": 18,
    "Kewarganegaraan": "Indonesia"
}
