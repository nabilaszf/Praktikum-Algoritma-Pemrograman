orang1 = {
    "Nama": "Nabila Firlina",
    "Umur": 18,
    "Kewarganegaraan": "Indonesia"
}